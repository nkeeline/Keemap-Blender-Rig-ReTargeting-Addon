bl_info = {
    "name": "KeeMap Anicmation Transfer Tool",
    "description": "Tools for moving animation from one Rig To Another",
    "author": "Nick Keeline",
    "version": (0, 0, 0),
    "blender": (2, 83, 0),
    "location": "3D View > Tools",
    "wiki_url": "https://github.com/nkeeline/Keemap-Blender-Rig-ReTargeting-Addon",
    "tracker_url": "https://github.com/nkeeline/Keemap-Blender-Rig-ReTargeting-Addon/issues",
    "category": "Animation"
}
 
import bpy
import sys
import importlib

modulesNames = [ 'KeeMapSettings', 'KeeMapBoneSettings', 'KeeMapBoneList', 'KeeMapBoneOperators', 'KeeMapPanels']


modulesFullNames = {}
for currentModuleName in modulesNames:
    if 'DEBUG_MODE' in sys.argv:
        modulesFullNames[currentModuleName] = ('{}'.format(currentModuleName))
    else:
        modulesFullNames[currentModuleName] = ('{}.{}'.format(__name__, currentModuleName))
 
for currentModuleFullName in modulesFullNames.values():
    if currentModuleFullName in sys.modules:
        importlib.reload(sys.modules[currentModuleFullName])
    else:
        globals()[currentModuleFullName] = importlib.import_module(currentModuleFullName)
        setattr(globals()[currentModuleFullName], 'modulesNames', modulesFullNames)
 
def register():
    for currentModuleName in modulesFullNames.values():
        if currentModuleName in sys.modules:
            if hasattr(sys.modules[currentModuleName], 'register'):
                sys.modules[currentModuleName].register()
 
def unregister():
    for currentModuleName in modulesFullNames.values():
        if currentModuleName in sys.modules:
            if hasattr(sys.modules[currentModuleName], 'unregister'):
                sys.modules[currentModuleName].unregister()
 
if __name__ == "__main__":
    register()